package com.phope.hope.Entity;

public enum Role {
    USER,
    ADMIN
}
