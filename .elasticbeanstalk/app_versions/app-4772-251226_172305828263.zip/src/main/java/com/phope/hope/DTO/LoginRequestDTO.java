package com.phope.hope.DTO;

public class LoginRequestDTO {
}
