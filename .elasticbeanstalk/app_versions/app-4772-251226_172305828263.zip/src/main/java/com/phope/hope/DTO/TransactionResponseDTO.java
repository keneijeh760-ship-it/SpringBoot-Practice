package com.phope.hope.DTO;

public class TransactionResponseDTO {
}
