package com.phope.hope.Repository;

public interface TransactionRepository {
}
