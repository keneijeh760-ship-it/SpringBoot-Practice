package com.phope.hope.Security;

public class CustomUserDetailsService {
}
