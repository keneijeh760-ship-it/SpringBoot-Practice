package com.phope.hope.Entity;

public class Role {
}
