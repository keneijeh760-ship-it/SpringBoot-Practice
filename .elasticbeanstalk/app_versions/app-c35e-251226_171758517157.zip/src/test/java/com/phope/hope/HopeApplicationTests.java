package com.phope.hope;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HopeApplicationTests {

    @Test
    void contextLoads() {
    }

}
