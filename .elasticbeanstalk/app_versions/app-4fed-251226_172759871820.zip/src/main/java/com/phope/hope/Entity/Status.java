package com.phope.hope.Entity;

public enum Status {
    SUCCESS,
    FAILURE,
    PENDING
}
